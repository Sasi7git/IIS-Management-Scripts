
# Script to backup IIS configuration

$backupPath = "C:\IIS_Backup"
if (!(Test-Path $backupPath)) {
    New-Item -Path $backupPath -ItemType Directory
}

$appcmd = "$env:SystemRoot\system32\inetsrv\appcmd.exe"
& $appcmd add backup "IISConfigBackup"
Write-Output "IIS configuration backed up to $backupPath."
    