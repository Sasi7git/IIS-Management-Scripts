
# Script to manage IIS Application Pools

param (
    [string]$AppPoolName,
    [string]$Action # Can be "start", "stop", or "recycle"
)

Import-Module WebAdministration

switch ($Action) {
    "start" { Start-WebAppPool -Name $AppPoolName }
    "stop" { Stop-WebAppPool -Name $AppPoolName }
    "recycle" { Restart-WebAppPool -Name $AppPoolName }
    default { Write-Output "Invalid action. Use 'start', 'stop', or 'recycle'." }
}

Write-Output "Action '$Action' executed on App Pool '$AppPoolName'."
    