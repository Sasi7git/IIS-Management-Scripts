
# Script to check the health of IIS websites and app pools

Import-Module WebAdministration

# Checking website statuses
$websites = Get-Website
$websites | ForEach-Object {
    Write-Output "Website: $($_.Name), Status: $($_.State)"
}

# Checking application pool statuses
$appPools = Get-WebAppPoolState
$appPools | ForEach-Object {
    Write-Output "App Pool: $($_.Name), Status: $($_.Value)"
}
    