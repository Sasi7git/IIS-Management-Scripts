
# Script to manage website bindings

param (
    [string]$SiteName,
    [string]$BindingInformation, # e.g., "*:80:"
    [string]$Protocol = "http"
)

Import-Module WebAdministration

New-WebBinding -Name $SiteName -BindingInformation $BindingInformation -Protocol $Protocol
Write-Output "Binding added for site '$SiteName' with binding information '$BindingInformation'."
    