
# Script to start and stop IIS services

param (
    [string]$Action = "start" # Can be "start" or "stop"
)

if ($Action -eq "start") {
    Start-Service -Name "W3SVC"
    Write-Output "IIS service started."
} elseif ($Action -eq "stop") {
    Stop-Service -Name "W3SVC"
    Write-Output "IIS service stopped."
} else {
    Write-Output "Invalid action. Please use 'start' or 'stop'."
}
    